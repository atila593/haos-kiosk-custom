# Script Python vide pour toggle clavier
print("Toggle keyboard script loaded")
