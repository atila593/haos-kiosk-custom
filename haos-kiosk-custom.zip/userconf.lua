-- Exemple de configuration Luakit
homepage = "http://homeassistant.local:8123"
