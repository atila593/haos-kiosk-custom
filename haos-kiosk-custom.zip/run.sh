#!/bin/bash
set -e

echo "RUN.SH STARTED at $(date)"

Xorg :0 -noreset +extension GLX +extension RANDR +extension RENDER &

sleep 2

openbox &

luakit &

python3 /rest_server.py &

tail -f /dev/null
